export * from "./validateHistoricParams";
export * from "./pluralize";
export * from "./CompactRenderer";
//# sourceMappingURL=index.d.ts.map