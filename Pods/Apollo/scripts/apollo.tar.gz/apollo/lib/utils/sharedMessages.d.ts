import { CLIError } from "@oclif/errors";
export declare const graphUndefinedError: CLIError;
//# sourceMappingURL=sharedMessages.d.ts.map